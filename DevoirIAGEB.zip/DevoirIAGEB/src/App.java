import java.util.List;
import java.util.Scanner;

import entities.Article;
import services.ArticleService;
import services.CategorieService;

public class App {
    /**
     * @param args
     * @throws Exception
     */
    public static void main(String[] args) throws Exception {
        int choix;
        try (Scanner sc = new Scanner(System.in)) {
            CategorieService CategorieService=new CategorieService();
            ArticleService bienService=new ArticleService();
      
            do {
                System.out.println("1-Creer Categorie");
                System.out.println("2-Lister les categories"); 
                System.out.println("3-Ajouter Article et l’ associée à une catégorie");
                System.out.println("4-Lister les articles ainsi que la catégorie associée");
                System.out.println("5-Quitter"); 
                 choix=sc.nextInt();
                 sc.nextLine();
                switch (choix) {
                    case 1:
                         System.out.println("Entrer le nom de la Categorie");
                         String nomCategorie=sc.nextLine(); 
                         Article categorie=new Article(choix, nomCategorie, nomCategorie, nomCategorie, null, nomCategorie, null);
                         categorie.setNomcategorie(nomCategorie);
                         CategorieService.CreerCategorie(categorie);
                        break;
                    case 2:
                        List<Article> ategorie = CategorieService.listerCategorie();
                        Article[] categories;
                        for (final Article cat : categories) {
                            System.out.println("ID : "+cat.getId() ); 
                            System.out.println("NOM : "+cat.getNomCategorie() );     
                        }
                      
                        break; 
                        
                         
                }
              } while (choix!=5);
        }
    }
}
