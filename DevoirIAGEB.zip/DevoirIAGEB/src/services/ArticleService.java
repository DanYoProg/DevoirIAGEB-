package services;
import java.util.List;
import entities.Article;
import repositories.ArticleRepository;


public class ArticleService {
    private ArticleRepository articleRepository=new ArticleRepository();
    public void ajouterArticle(Article Article){
        articleRepository.insertArticle(Article);
    }
    public List<Article> listerarticle(){
          return   articleRepository.getAllArticles();
    }
      
}
