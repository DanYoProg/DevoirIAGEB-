package services;

import java.util.List;

import entities.Article;
import repositories.CategorieRepository;

public class CategorieService {
    private CategorieRepository zoneRepository=new CategorieRepository();
    public void ajouterZone(Article zone){
        CategorieRepository categorieRepository;
        Object categorie;
        categorieRepository.insertCategorie(categorie);
    }
    public List<Article> listerArticle(){
          return categorieRepository.getAllCategorie();
    }
    public void CreerCategorie(Article categorie) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'CreerCategorie'");
    }
    public List<Article> listerCategorie() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'listerCategorie'");
    }
    
}
