package repositories;

import java.util.List;

import entities.Article;

public class ArticleRepository  extends Database{

    public void insertArticle(Article article) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'insertArticle'");
    }

    public List<Article> getAllArticles() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getAllArticles'");
    }
   
}
