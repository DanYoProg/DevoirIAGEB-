package repositories;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import entities.Article;

public class CategorieRepository extends Database {
        private final  String SQL_SELECT_ALL="select * from categorie" ;
        private final  String SQL_INSERT="INSERT INTO zone (nom_categorie) VALUES (?)";
        //select
       public void insertZone(Article categorie){
            openConnexion();
            try {
                initPreparedStatement(SQL_INSERT);
                statement.setString(1, categorie.getNomCategorie());
                closeConnexion();
            } catch (SQLException e) {
            e.printStackTrace();
            }
       }
       public List<Article> getAllCategorie(){
            List<Article> zones=new ArrayList<>();
       try {
           openConnexion();
           initPreparedStatement(SQL_SELECT_ALL);
           ResultSet rs= executeSelect();
             while (rs.next()) {
                  Article categorie=new Article(0, SQL_INSERT, SQL_INSERT, SQL_INSERT, null, SQL_INSERT, zones);
                  categorie.setId(rs.getInt("id_categorie"));
                  categorie.setNomZone(rs.getString("nom_categorie"));
                  categorie.add(categorie);
             }
             rs.close();
           closeConnexion();
        }
         catch (SQLException e) {
              System.out.println("Erreur de Connexion a la BD");
        }
        return  zones;
       }
    public void insertCategorie(Object categorie) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'insertCategorie'");
    }
}
