package entities;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

public class Article {
    private int id;
    private String nomZone;
    private String titre;
    private String contenue;
    private Date dateCreation;
    private String etat;

    List<Article> articles=new ArrayList<>();

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNomZone() {
        return nomZone;
    }

    public void setNomZone(String nomZone) {
        this.nomZone = nomZone;
    }

    public String getTitre() {
        return titre;
    }

    public void setTitre(String titre) {
        this.titre = titre;
    }

    public String getContenue() {
        return contenue;
    }

    public void setContenue(String contenue) {
        this.contenue = contenue;
    }

    public Date getDateCreation() {
        return dateCreation;
    }

    public void setDateCreation(Date dateCreation) {
        this.dateCreation = dateCreation;
    }

    public String getEtat() {
        return etat;
    }

    public void setEtat(String etat) {
        this.etat = etat;
    }

    public List<Article> getArticles() {
        return articles;
    }

    public void setArticles(List<Article> articles) {
        this.articles = articles;
    }

    public Article(int id, String nomZone, String titre, String contenue, Date dateCreation, String etat,
            List<Article> articles) {
        this.id = id;
        this.nomZone = nomZone;
        this.titre = titre;
        this.contenue = contenue;
        this.dateCreation = dateCreation;
        this.etat = etat;
        this.articles = articles;
    }

    public String getNomCategorie() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getNomCategorie'");
    }

    public void setNomcategorie(String nomCategorie) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'setNomcategorie'");
    }

    /**
     * @param categorie
     */
    public void add(Article categorie) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'add'");
    }

  
    
}
