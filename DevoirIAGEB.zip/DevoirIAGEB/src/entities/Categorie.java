package entities;

public class Categorie {
    private int id;
    private String NomCat;
    public Categorie(int id, String nomCat) {
        this.id = id;
        NomCat = nomCat;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getNomCat() {
        return NomCat;
    }
    public void setNomCat(String nomCat) {
        NomCat = nomCat;
    }
   
    
    

}
